########################################
# Generate overviews for layer files in source dir and updates oracle featureclass with new overviews.
# This technique is advantages as the web services does not need to be stopped to do the updates.
# This script also uses the in memory workspace, which greatly speeds up processing time.
# Written by David Spriggs, ESRI, March 22nd 2011.
########################################

import arcgisscripting, os, re, time

gp = arcgisscripting.create(9.3)

serviceToken = gp.getparameterastext(0)

sourceDir = r"\\spatial2\agsresources\gdp\GDP_Tools\UpdateOverviews\LayersToUpdate" # folder that contains all the layer files to generate overviews on
sdeConnection = r"\\spatial2\agsresources\gdp\GDP_Tools\UpdateOverviews\oracle8_DC_gw_pub.sde" # SDE connection file with update/delete rights.
sdeUser = "GW_PUB." # assuming that the GW_PUB user created/owner of table include the . at the end

gp.addmessage("Preparing scratch workspace and gp objects...<br/><br/>")
gp.overwriteoutput = True
gp.workspace = sdeConnection # set workspace to in memory
currentOVs = gp.listfeatureclasses("*_OV")
gp.workspace = "in_memory" # set workspace to in memory

if serviceToken == "gdp":
    files = os.listdir(sourceDir)
    for file in files:
        if re.match(".*\.lyr", file):
            tempOV = file.split(".")[0] + "_OV" # append _OV to the layer files name
            gp.addmessage("Creating overview for: " + file + ", Start time: " + time.strftime("%a %d %b %Y %H:%M:%S", time.localtime(time.time())))
            if sdeUser + tempOV in currentOVs:
                gp.addmessage("Overview does exist.")
                try:
                    gp.Dissolve_management(sourceDir + os.sep + file, tempOV)
                    gp.addmessage("Truncating oracle FC...")
                    gp.DeleteFeatures_management(sdeConnection + os.sep + sdeUser + tempOV)
                    gp.addmessage("Apending new overview to oracle FC...")
                    gp.Append_management(tempOV, sdeConnection + os.sep + sdeUser + tempOV, "NO_TEST")
                    gp.addmessage("Cleaning memory...")
                    gp.Delete_management(tempOV) # clean up the in memory workspace so we dont overload the memory on the host machine
                except Exception, err:
                    gp.addwarning("Failed to update overview layer.")
                    gp.addwarning(str(err))
            else:
                gp.addwarning("Overview does not currently exist.")
                gp.addmessage("Creating new overview...")
                try:
                    gp.Dissolve_management(sourceDir + os.sep + file, sdeConnection + os.sep + tempOV)
                    gp.addmessage("Success creating new overview layer.")
                except Exception, err:
                    gp.addwarning("Failed to create new overview layer.")
                    gp.addwarning(str(err))
            
            gp.addmessage("Done creating overview for: " + file + ", Finish time: " + time.strftime("%a %d %b %Y %H:%M:%S", time.localtime(time.time())) + "<br/><br/>")
else:
    gp.adderror("Incorrect service token.<br/><br/>")
