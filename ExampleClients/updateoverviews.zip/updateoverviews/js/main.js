dojo.require("dijit.layout.BorderContainer");
dojo.require("dijit.layout.TabContainer");
dojo.require("dijit.layout.ContentPane");
dojo.require("dijit.Dialog");
dojo.require("dijit.ProgressBar");
dojo.require("dijit.form.TextBox");
dojo.require("esri.tasks.gp");

var ou = {
	enterToken: null,
	
	overviewUpdateService: new esri.tasks.Geoprocessor("http://wwwego.geoint.nga.smil.mil/dev/rest/services/gdp/GDP_Tools/GPServer/UpdateOverviews"),
	
	buildUI: function(){
		var outer = new dijit.layout.BorderContainer({
													 style: "width:100%;height:100%;border:0;",
													 design: "headline",
													 liveSplitters: false
													 }).placeAt(dojo.body());
		new dijit.layout.ContentPane({
									  region: "top",
									  style: "height:95px;background-color:#000;",
									  href: "html/header.html"
									  }).placeAt(outer);
		new dijit.layout.ContentPane({
									  region: "left",
									  style: "width:250px;text-align:center;",
									  href: "html/tools.html",
									  splitter: true
									  }).placeAt(outer);
		ou.tabContainer = new dijit.layout.TabContainer({
														 region: "center",
														 id: "tabContainer"
														 }).placeAt(outer);
		new dijit.layout.ContentPane({
									  id: "messages",
									  title: "Live Job",
									  closable: false,
									  selected: true,
									  href: "html/results.html"
									  }).placeAt(ou.tabContainer);
		outer.startup();
		},
	
	showGetTokenDLG: function(){
		if (ou.enterToken === null){
		  ou.enterToken = new dijit.Dialog({
											title: "Please enter the service token",
											dragable: false,
											style: "width:250px;",
											href: "html/enterToken.html"
											});
		  ou.enterToken.show();
		  dojo.connect(ou.enterToken, "onLoad", function(evt){
			   	dojo.connect(dijit.byId("tokenTXT"), "onKeyUp", function(evt){
						if (evt.keyCode == dojo.keys.ENTER){ou.callOverviewUpdateService(dijit.byId("tokenTXT").get("value"));}
			   		});
			   });
		} else {
			ou.enterToken.show();
			}
		},
		
	callOverviewUpdateService: function(token){
		if (token){
			ou.tabContainer.selectChild(dijit.byId("messages"));
			dijit.byId("createNewOverViewsBTN").set("disabled", true);
			ou.enterToken.hide();
			new dijit.ProgressBar({
								   indeterminate: true
								   }, dojo.create("div")).placeAt(dojo.byId("progressBar"));
			
			var params = {
				serviceToken: token
				};
			ou.overviewUpdateService.setUpdateDelay(1000); //value in milliseconds
			ou.overviewUpdateService.submitJob(params, ou.overviewUpdateComplete, ou.overviewUpdateStatus, ou.overviewUpdateError);
			}
		},
		
	overviewUpdateComplete: function(jobInfo){
		dojo.empty("progressBar");
		dijit.byId("createNewOverViewsBTN").set("disabled", false);
		},
		
	overviewUpdateStatus: function(jobInfo){
		if (dojo.byId("gpJobId").innerHTML != jobInfo.jobId){
			dojo.byId("gpJobId").innerHTML = "Job ID: <b>" + jobInfo.jobId + "</b>";
		}
		dojo.byId("jobStatus").innerHTML = "Job Status: <b>" + jobInfo.jobStatus + "</b>";
		dojo.empty("gpMessages");
		dojo.forEach(jobInfo.messages, function(message){
												dojo.create("div", {
															innerHTML: message.description,
															"class": message.type
															}, "gpMessages", "last");
												});
		},
		
	overviewUpdateError: function(jobInfo){
		dojo.empty("progressBar");
		dijit.byId("createNewOverViewsBTN").set("disabled", false);
		dojo.empty("gpMessages");
		dojo.byId("gpMessages").innerHTML = "An error ocurred calling the service, please try again.<br/><br/>" + jobInfo.message;
		},
		
	checkPriorJobStatus: function(jobId){
		if (jobId){
		  if(typeof dijit.byId(jobId) == "undefined"){
			dijit.byId("checkJobStatusBTN").set("disabled", true);
			var tab = new dijit.layout.ContentPane({
										  title: jobId,
										  id: jobId,
										  closable: true
										  }).placeAt(ou.tabContainer);
			ou.tabContainer.selectChild(tab);
			new dijit.ProgressBar({
								   indeterminate: true
								   }, dojo.create("div")).placeAt(tab.containerNode);
		  } else{
			  ou.tabContainer.selectChild(dijit.byId(jobId));
			  }
			ou.overviewUpdateService.checkJobStatus(jobId, ou.checkPriorJobStatusComplete, dojo.hitch(tab, function(err, tab){ou.checkPriorJobStatusError(err,jobId)}));
		  }
		},
		
		checkPriorJobStatusComplete: function(jobInfo){
			var tab = dijit.byId(jobInfo.jobId);
			dojo.empty(tab.containerNode);
			dojo.create("div", {
								innerHTML: "Job ID: <b>" + jobInfo.jobId + "</b><br/>Job Status: <b>" + jobInfo.jobStatus + "</b>"
								}, tab.containerNode, "last");
			dojo.forEach(jobInfo.messages, function(message){
													dojo.create("div", {
																innerHTML: message.description,
																"class": message.type
																}, tab.containerNode, "last");
													});
			new dijit.form.Button({
								  label: "Refresh job info",
								  onClick: dojo.hitch(tab, function(evt){
																	ou.checkPriorJobStatus(tab.id);
																	}) 
								  }).placeAt(tab.containerNode, "last");
			dijit.byId("checkJobStatusBTN").set("disabled", false);
			},
			
		checkPriorJobStatusError: function(err, jobId){
			var tab = dijit.byId(jobId);
			dojo.empty(tab.containerNode);
			tab.set("content", err.message);
			dijit.byId("checkJobStatusBTN").set("disabled", false);
			}
};

dojo.ready(ou.buildUI);